# DingRTC SDK （Android）

## 下载最新 DingRTC SDK

将[dingrtc.aar](https://help.aliyun.com/document_detail/71770.html)拷贝到此目录。
